using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaterialAssigner : MonoBehaviour
{
    public Material targetMaterial;

    void Start()
    {
        SpriteRenderer[] renderers = FindObjectsOfType<SpriteRenderer>();
        foreach (var renderer in renderers)
        {
            renderer.material = targetMaterial;
        }
    }
}
